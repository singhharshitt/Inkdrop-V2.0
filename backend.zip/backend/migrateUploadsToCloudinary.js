// migrateUploadsToCloudinary.js

const fs = require('fs');
const path = require('path');
const cloudinary = require('cloudinary').v2;
const mongoose = require('mongoose');
const dotenv = require('dotenv');
const Book = require('./models/Book'); // adjust path as needed

dotenv.config();

cloudinary.config({
  cloud_name: process.env.CLOUD_NAME,
  api_key: process.env.CLOUD_API_KEY,
  api_secret: process.env.CLOUD_API_SECRET,
});

mongoose.connect(process.env.MONGO_URI)
  .then(() => console.log("MongoDB connected"))
  .catch(err => console.log("Mongo error:", err));

const uploadFolderToCloudinary = async () => {
  const books = await Book.find();

  for (let book of books) {
    let updated = false;

    // 📘 Upload cover
    if (book.cover && !book.cover.startsWith("http")) {
      const localCoverPath = path.join(__dirname, book.cover);
      if (fs.existsSync(localCoverPath)) {
        const res = await cloudinary.uploader.upload(localCoverPath, {
          folder: 'inkdrop/covers',
        });
        book.cover = res.secure_url;
        updated = true;
      }
    }

    // 📄 Upload pdf
    if (book.pdf && !book.pdf.startsWith("http")) {
      const localPdfPath = path.join(__dirname, book.pdf);
      if (fs.existsSync(localPdfPath)) {
        const res = await cloudinary.uploader.upload(localPdfPath, {
          folder: 'inkdrop/pdfs',
          resource_type: 'raw',
        });
        book.pdf = res.secure_url;
        updated = true;
      }
    }

    if (updated) {
      await book.save();
      console.log(`Updated book: ${book.title}`);
    }
  }

  console.log("✅ Migration complete");
  mongoose.disconnect();
};

uploadFolderToCloudinary();
