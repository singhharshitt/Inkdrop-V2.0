const multer = require('multer');
const path = require('path');
const fs = require('fs');
const { v2: cloudinary } = require('cloudinary');
const { CloudinaryStorage } = require('multer-storage-cloudinary');
require('dotenv').config();

// Setup Cloudinary if credentials exist
const useCloudinary = process.env.CLOUD_NAME && process.env.CLOUD_API_KEY && process.env.CLOUD_API_SECRET;

if (useCloudinary) {
  cloudinary.config({
    cloud_name: process.env.CLOUD_NAME,
    api_key: process.env.CLOUD_API_KEY,
    api_secret: process.env.CLOUD_API_SECRET,
  });
}

// Create directory if needed for local storage
const ensureDirExists = (dir) => {
  if (!fs.existsSync(dir)) {
    fs.mkdirSync(dir, { recursive: true });
  }
};

// File filter (same as before)
const fileFilter = (req, file, cb) => {
  const imageTypes = ['.jpg', '.jpeg', '.png', '.webp'];
  const docTypes = ['.pdf', '.epub'];
  const ext = path.extname(file.originalname).toLowerCase();

  if (
    (file.fieldname === 'cover' && imageTypes.includes(ext)) ||
    (file.fieldname === 'pdf' && docTypes.includes(ext))
  ) {
    cb(null, true);
  } else {
    cb(new Error(`Invalid file type for ${file.fieldname}`), false);
  }
};

// ===== STORAGE SETUP =====
let storage;

if (useCloudinary) {
  storage = new CloudinaryStorage({
    cloudinary,
    params: async (req, file) => {
      const folder = file.fieldname === 'cover' ? 'book_covers' : 'book_pdfs';
      const ext = path.extname(file.originalname).toLowerCase();
      return {
        folder,
        resource_type: ext === '.pdf' || ext === '.epub' ? 'raw' : 'image',
        public_id: `${Date.now()}-${file.originalname.replace(/[^a-zA-Z0-9.]/g, '-')}`,
      };
    },
  });
} else {
  storage = multer.diskStorage({
    destination: function (req, file, cb) {
      const baseDir = 'uploads';
      const subDir = file.fieldname === 'cover' ? 'covers' : 'pdfs';
      const fullDir = path.join(baseDir, subDir);
      ensureDirExists(fullDir);
      cb(null, fullDir);
    },
    filename: function (req, file, cb) {
      const sanitizedName = file.originalname.replace(/[^a-zA-Z0-9.]/g, '-');
      const uniqueName = `${Date.now()}-${sanitizedName}`;
      cb(null, uniqueName);
    }
  });
}

// ===== MULTER INSTANCE =====
const upload = multer({
  storage,
  fileFilter,
  limits: {
    fileSize: 50 * 1024 * 1024 // 50MB max
  }
});

// ===== MIDDLEWARES =====
const uploadBook = upload.fields([
  { name: 'cover', maxCount: 1 },
  { name: 'pdf', maxCount: 1 }
]);

const handleUploadErrors = (err, req, res, next) => {
  if (err instanceof multer.MulterError) {
    return res.status(400).json({
      success: false,
      message: err.code === 'LIMIT_FILE_SIZE'
        ? 'File too large. Max 50MB allowed.'
        : 'Upload error: ' + err.message
    });
  } else if (err) {
    return res.status(400).json({
      success: false,
      message: err.message || 'Upload error occurred'
    });
  }
  next();
};

// ===== EXPORTS =====
module.exports = {
  uploadBook,
  uploadMultipleBooks: upload.array('bookFiles', 3), // (still local)
  handleUploadErrors
};
